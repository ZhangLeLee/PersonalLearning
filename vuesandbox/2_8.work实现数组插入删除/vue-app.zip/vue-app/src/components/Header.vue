<template>
	<header>
		
	</header>
</template>

<script>
	export default {
		data(){
		    return {
		      	
		    }
		},
	    methods:{
	    
	    }
	}

</script>

<style scoped>
  
</style>



